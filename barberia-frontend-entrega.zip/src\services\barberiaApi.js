import { mockAppointments, mockBarbers, mockBranches, mockClientes, mockPromotions, mockServices } from '../data/mockData';

const API_BASE = 'http://localhost:8081';

async function fetchJson(url, fallbackData, options = {}) {
  try {
    const response = await fetch(url, {
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    return fallbackData;
  }
}

export const getServices = async () => fetchJson(`${API_BASE}/api/v1/servicios`, mockServices);
export const getBarbers = async () => fetchJson(`${API_BASE}/api/v1/barberos`, mockBarbers);
export const getBranches = async () => fetchJson(`${API_BASE}/sucursales`, mockBranches);
export const getPromotions = async () => fetchJson(`${API_BASE}/promociones`, mockPromotions);
export const getClients = async () => fetchJson(`${API_BASE}/clientes`, mockClientes);
export const getAppointments = async (clientId = 1) => {
  const response = await fetchJson(`${API_BASE}/api/v1/citas/cliente/${clientId}`, mockAppointments, {
    headers: { rol: 'CLIENTE', usuarioId: String(clientId) }
  });
  return Array.isArray(response) ? response : [];
};

export const createAppointment = async (payload) => {
  const appointment = {
    ...payload,
    id: Date.now(),
    estado: 'PENDIENTE'
  };

  try {
    const response = await fetch(`${API_BASE}/api/v1/citas`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        rol: 'CLIENTE',
        usuarioId: '1'
      },
      body: JSON.stringify(appointment)
    });

    if (!response.ok) {
      throw new Error('No se pudo reservar la cita');
    }

    return await response.json();
  } catch (error) {
    return appointment;
  }
};

export const getAdminRecords = async () => ({
  servicios: await getServices(),
  barberos: await getBarbers(),
  sucursales: await getBranches(),
  citas: await getAppointments(),
  promociones: await getPromotions(),
  inventario: [
    { id: 1, producto: 'Gel para cabello', stock: 32, categoria: 'Producto de cuidado' },
    { id: 2, producto: 'Máquina de recorte', stock: 4, categoria: 'Equipo' }
  ],
  pagos: [
    { id: 1, concepto: 'Corte clásico', monto: 18000, metodo: 'Tarjeta', estado: 'Pagado' },
    { id: 2, concepto: 'Combo corte + barba', monto: 26000, metodo: 'WebPay', estado: 'Pendiente' }
  ]
});
